﻿class FuncDelegate
{
    static int SumNumbers(int a, int b, int c)
    {
        return a + b + c;
    }

    static void Main(string[] args)
    {
        Func<int, int, int, int> addThreeNumbers = SumNumbers;
        int result = SumNumbers(5, 10, 15);
        Console.WriteLine(result);

        Func<int> getMyFavoriteNumber = delegate ()
        {
            Random random = new Random();
            return random.Next(1, 1000);
        };

        Func<int> getMySecondFavoriteNumber = () => new Random().Next(1, 1000);
    }
}