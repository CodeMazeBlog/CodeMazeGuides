class Program
{
    static void Main(string[] args)
    {
        Action<int> printMyActionDelegate = PrintIt;
        printMyActionDelegate(500);
    }

    static void PrintIt (int i)
    {
        Console.WriteLine(i);
    }
}