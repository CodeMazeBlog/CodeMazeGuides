class Program
{
    static void Main(string[] args)
    {
        
    }

    static void PrintIt (int i)
    {
        Console.WriteLine(i);
    }

    Action<int> printMyActionDelegate = PrintIt;
    printMyActionDelegate(500);
}